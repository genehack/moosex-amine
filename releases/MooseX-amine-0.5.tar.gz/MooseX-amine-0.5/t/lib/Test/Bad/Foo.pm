# Comment
package Bar;
use Moose;
1;
